import 'package:flutter/material.dart';

class VerifyOtp extends StatelessWidget {
  const VerifyOtp({super.key, required this.email});

  final String email;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [Text("Verify your otp send on $email")]),
      ),
    );
  }
}
